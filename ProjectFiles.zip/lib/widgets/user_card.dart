// UI card for displaying downline members
