// Chat bubble UI widget
