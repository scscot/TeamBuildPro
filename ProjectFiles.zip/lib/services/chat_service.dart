import 'package:flutter/material.dart';

class ChatService {
  Future<void> sendMessage(String userId, String message) async {
    // Placeholder for chat logic
    debugPrint('Sending message from $userId: $message');
  }
}
