class DownlineService {
  Future<List<String>> fetchDirects(String userId) async {
    // Simulate fetching downline structure
    return ['userA', 'userB', 'userC'];
  }
}
